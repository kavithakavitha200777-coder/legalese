"""Gemini integration: builds the prompt and generates the legal document text."""
import logging
import time

import config

log = logging.getLogger("legalease.gemini")

SYSTEM_INSTRUCTION = (
    "You are an experienced legal drafter. You produce clear, well-structured, formal legal "
    "documents in plain text. You never add commentary, explanations or disclaimers outside "
    "the document itself."
)


class GeminiError(Exception):
    """Raised when document generation fails (bad key, quota, network, empty reply...)."""


class GeminiDocumentGenerator:
    def __init__(self, model_name: str | None = None, api_key: str | None = None):
        self.model_name = model_name or config.GEMINI_MODEL
        self.api_key = api_key or config.GEMINI_API_KEY
        self._client = None       # google-genai client (lazy)
        self._legacy = None       # google.generativeai module (lazy fallback)

    # ------------------------------------------------------------------ prompt
    @staticmethod
    def build_prompt(document_type: str, parties: str, terms: str, dates: str) -> str:
        terms_list = [t.strip() for t in terms.replace("\n", ";").split(";") if t.strip()]
        terms_block = "\n".join(f"- {t}" for t in terms_list) or (
            "Not specified - use standard, balanced clauses for this type of document."
        )
        return (
            f"Draft a comprehensive, professional legal document titled '{document_type}'.\n\n"
            f"Involved parties (names and roles):\n{parties.strip()}\n\n"
            f"Effective date: {dates.strip() or 'Not specified - use [Effective Date] placeholder'}\n\n"
            f"Terms and conditions that MUST be reflected as clauses:\n{terms_block}\n\n"
            "FORMATTING RULES (strict):\n"
            "1. Output plain text only. No Markdown: no #, *, ** or backticks, no tables.\n"
            "2. First line: the document title in capital letters.\n"
            "3. Then an opening paragraph (date and parties), then recitals if appropriate.\n"
            "4. Number every section heading on its own line, e.g. '1. Definitions' "
            "(heading text only, no trailing period), followed by its paragraphs.\n"
            "5. Use 'a)', 'b)', 'c)' on separate lines for sub-clauses.\n"
            "6. Include: scope/purpose, obligations, payment or consideration (if relevant), "
            "confidentiality, term and termination, liability, dispute resolution, governing law, "
            "entire agreement and severability - as appropriate for this document type.\n"
            "7. Where information is missing, use square-bracket placeholders such as "
            "[Address] or [Amount]. Never invent facts.\n"
            "8. End with 'IN WITNESS WHEREOF, the parties have executed this document as of the "
            "Effective Date.' followed by a signature block for each party using a line of "
            "underscores, the party's name and role, and 'Date: ____________'.\n"
        )

    # ------------------------------------------------------------------ mock
    @staticmethod
    def _mock_document(document_type, parties, terms, dates) -> str:
        items = [t.strip() for t in terms.replace("\n", ";").split(";") if t.strip()]
        clauses = "\n".join(f"{chr(97 + i % 26)}) {t}" for i, t in enumerate(items)) or "a) [Terms to be specified]"
        sigs = "\n\n".join(
            f"______________________________\n{p.strip()}\nDate: ____________"
            for p in parties.replace(";", "\n").split("\n") if p.strip()
        ) or "______________________________\n[Party]\nDate: ____________"
        return (
            f"{document_type.upper()}\n\n"
            f"This {document_type} (the \"Agreement\") is made effective as of {dates or '[Effective Date]'} "
            f"between the following parties:\n{parties.strip()}\n\n"
            "1. Purpose and Scope\n"
            f"The parties enter into this {document_type} to record their mutual rights and obligations.\n\n"
            "2. Terms and Conditions\n"
            "The parties agree to the following terms:\n"
            f"{clauses}\n\n"
            "3. Confidentiality\n"
            "Each party shall keep confidential all non-public information received from the other party.\n\n"
            "4. Term and Termination\n"
            "This Agreement begins on the Effective Date and continues until performed in full or terminated "
            "in accordance with its terms.\n\n"
            "5. Governing Law\n"
            "This Agreement is governed by the laws of [Jurisdiction].\n\n"
            "6. Entire Agreement\n"
            "This Agreement is the entire understanding of the parties on its subject matter.\n\n"
            "IN WITNESS WHEREOF, the parties have executed this document as of the Effective Date.\n\n"
            f"{sigs}\n\n[MOCK MODE - built-in template, not AI generated]"
        )

    # ------------------------------------------------------------------ SDK plumbing
    def _call_model(self, model: str, prompt: str) -> str:
        """Single call to Gemini using google-genai (preferred) or google-generativeai (legacy)."""
        try:
            from google import genai
            from google.genai import types

            if self._client is None:
                self._client = genai.Client(api_key=self.api_key)
            resp = self._client.models.generate_content(
                model=model,
                contents=prompt,
                config=types.GenerateContentConfig(
                    system_instruction=SYSTEM_INSTRUCTION, temperature=0.4
                ),
            )
            return (resp.text or "").strip()
        except ImportError:
            pass  # new SDK not installed -> try legacy

        try:
            import google.generativeai as legacy
        except ImportError as exc:
            raise GeminiError(
                "No Gemini SDK installed. Run: pip install google-genai"
            ) from exc
        if self._legacy is None:
            legacy.configure(api_key=self.api_key)
            self._legacy = legacy
        m = self._legacy.GenerativeModel(model, system_instruction=SYSTEM_INSTRUCTION)
        return (m.generate_content(prompt).text or "").strip()

    # ------------------------------------------------------------------ public API
    def generate_document(self, document_type: str, parties: str, terms: str, dates: str) -> str:
        if config.MOCK_MODE:
            return self._mock_document(document_type, parties, terms, dates)
        if not self.api_key:
            raise GeminiError(
                "GEMINI_API_KEY is missing. Add it to the .env file (or set MOCK_MODE=true to test)."
            )

        prompt = self.build_prompt(document_type, parties, terms, dates)
        candidates = [self.model_name] + [m for m in config.GEMINI_FALLBACK_MODELS if m != self.model_name]
        last_error: Exception | None = None

        for model in candidates:
            for attempt in range(2):  # one retry for transient errors
                try:
                    text = self._call_model(model, prompt)
                    if text:
                        return text
                    last_error = GeminiError("The model returned an empty response.")
                except GeminiError:
                    raise
                except Exception as exc:  # network / quota / model-not-found / auth
                    last_error = exc
                    msg = str(exc).lower()
                    log.warning("Model %s attempt %d failed: %s", model, attempt + 1, exc)
                    if any(k in msg for k in ("api key", "api_key", "permission", "unauthenticated", "401", "403")):
                        raise GeminiError(f"Gemini rejected the API key: {exc}") from exc
                    if any(k in msg for k in ("not found", "404", "no longer available", "deprecated")):
                        break  # try next model immediately
                    time.sleep(1.5)
        raise GeminiError(f"Document generation failed: {last_error}")
