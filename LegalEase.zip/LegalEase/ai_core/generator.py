"""Formatting utilities: sanitize, parse, and export (DOCX / PDF / HTML preview).

Pure-Python helpers with no Gemini dependency, used by the Streamlit frontend.
"""
import html
import io
import os
import re

import config

# --------------------------------------------------------------------------- sanitizing
_REPLACEMENTS = {
    "\u2018": "'", "\u2019": "'", "\u201a": "'", "\u201c": '"', "\u201d": '"', "\u201e": '"',
    "\u2013": "-", "\u2014": "-", "\u2212": "-", "\u2026": "...", "\u00a0": " ",
    "\u2022": "-", "\u25cf": "-", "\u2192": "->", "\u200b": "",
}


def sanitize_text(text: str) -> str:
    """Remove typographic characters and stray Markdown so exports stay clean."""
    if not text:
        return ""
    for src, dst in _REPLACEMENTS.items():
        text = text.replace(src, dst)
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"```[a-zA-Z]*", "", text)
    text = re.sub(r"\*\*(.+?)\*\*", r"\1", text)          # **bold**
    text = re.sub(r"(?m)^\s{0,3}#{1,6}\s*", "", text)      # ## headings
    text = re.sub(r"(?m)^\s*\*\s+", "- ", text)            # "* item" -> "- item"
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def split_terms(terms: str) -> list[str]:
    """Semicolon / newline separated terms -> clean list."""
    return [t.strip(" -\t") for t in re.split(r"[;\n]", terms or "") if t.strip(" -\t")]


def safe_filename(name: str, ext: str) -> str:
    base = re.sub(r"[^A-Za-z0-9]+", "_", name or "legal_document").strip("_").lower() or "legal_document"
    return f"{base}.{ext}"


# --------------------------------------------------------------------------- parsing
_NUM_HEADING = re.compile(r"^(\d+(?:\.\d+)*[.)]?)\s+\S.{0,70}$")
_SUB = re.compile(r"^(\(?[a-z]\)|\(?[ivx]+\)|\(\d+\))\s+\S")
_BULLET = re.compile(r"^[-*]\s+\S")


def _is_heading(line: str) -> bool:
    if len(line) > 75:
        return False
    if _NUM_HEADING.match(line) and not line.rstrip(":").endswith((".", ";", ",")) and len(line.split()) <= 10:
        return True
    if line.endswith(":") and len(line.split()) <= 4:
        return True
    return line.isupper() and any(c.isalpha() for c in line)


def parse_document(text: str, doc_type: str = "") -> list[tuple[str, str]]:
    """Return [(kind, text)] where kind in title|heading|para|sub|bullet."""
    lines = [ln.strip() for ln in sanitize_text(text).split("\n")]
    blocks: list[tuple[str, str]] = []
    first = True
    for ln in lines:
        if not ln:
            continue
        if first:
            first = False
            if len(ln) <= 90 and not ln.endswith("."):
                blocks.append(("title", ln))
                continue
            blocks.append(("title", (doc_type or "Legal Document").strip()))
        if re.fullmatch(r"_{5,}", ln):
            blocks.append(("para", ln))
        elif _BULLET.match(ln):
            blocks.append(("bullet", ln[1:].strip()))
        elif _SUB.match(ln):
            blocks.append(("sub", ln))
        elif _is_heading(ln):
            blocks.append(("heading", ln))
        else:
            blocks.append(("para", ln))
    if not blocks:
        blocks.append(("title", (doc_type or "Legal Document").strip()))
    return blocks


def build_blocks(text: str, doc_type: str, terms: str = "") -> list[tuple[str, object]]:
    """Parsed blocks + a 'terms' block inserted before the signature section."""
    blocks: list[tuple[str, object]] = list(parse_document(text, doc_type))
    items = split_terms(terms)
    if items:
        idx = next(
            (i for i, (k, t) in enumerate(blocks) if k != "title" and str(t).upper().startswith("IN WITNESS")),
            len(blocks),
        )
        blocks[idx:idx] = [("heading", "Summary of Key Terms"), ("terms", items)]
    return blocks


# --------------------------------------------------------------------------- HTML preview
def format_html_preview(text: str) -> str:
    """Escaped, semantic HTML (single line - safe to embed in st.markdown)."""
    parts = []
    for kind, content in parse_document(text):
        c = html.escape(content)
        if kind == "title":
            parts.append(f"<h2 style='text-align:center;margin:0 0 14px 0;'>{c}</h2>")
        elif kind == "heading":
            parts.append(f"<h4 style='margin:16px 0 4px 0;'>{c}</h4>")
        elif kind == "sub":
            parts.append(f"<p style='margin:2px 0 2px 24px;'>{c}</p>")
        elif kind == "bullet":
            parts.append(f"<p style='margin:2px 0 2px 24px;'>&bull; {c}</p>")
        else:
            parts.append(f"<p style='margin:4px 0;text-align:justify;'>{c}</p>")
    return "".join(parts)


# --------------------------------------------------------------------------- DOCX
def _add_page_number(paragraph):
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    run = paragraph.add_run()
    for tag, txt in (("begin", None), (None, "PAGE"), ("end", None)):
        if tag:
            el = OxmlElement("w:fldChar")
            el.set(qn("w:fldCharType"), tag)
        else:
            el = OxmlElement("w:instrText")
            el.set(qn("xml:space"), "preserve")
            el.text = txt
        run._r.append(el)
    from docx.shared import Pt as _Pt
    run.font.size = _Pt(9)


def format_docx(text: str, doc_type: str, terms: str = "") -> bytes:
    """Word document: logo (first page), Times New Roman, terms table, footer with page numbers."""
    from docx import Document
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Inches, Pt, RGBColor

    doc = Document()
    for s in doc.sections:
        s.left_margin = s.right_margin = s.top_margin = s.bottom_margin = Inches(1)

    normal = doc.styles["Normal"]
    normal.font.name = "Times New Roman"
    normal.font.size = Pt(12)
    normal.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    if "List Bullet" in [st.name for st in doc.styles]:
        doc.styles["List Bullet"].font.name = "Times New Roman"

    if os.path.exists(config.LOGO_PATH):
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.add_run().add_picture(config.LOGO_PATH, width=Inches(2.4))

    for kind, content in build_blocks(text, doc_type, terms):
        if kind == "title":
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_after = Pt(12)
            r = p.add_run(str(content))
            r.bold = True
            r.font.size = Pt(16)
        elif kind == "heading":
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(12)
            p.paragraph_format.space_after = Pt(4)
            p.paragraph_format.keep_with_next = True
            p.add_run(str(content)).bold = True
        elif kind == "sub":
            p = doc.add_paragraph(str(content))
            p.paragraph_format.left_indent = Inches(0.4)
            p.paragraph_format.space_after = Pt(3)
        elif kind == "bullet":
            doc.add_paragraph(str(content), style="List Bullet")
        elif kind == "terms":
            table = doc.add_table(rows=1, cols=2)
            table.style = "Table Grid"
            table.alignment = WD_TABLE_ALIGNMENT.CENTER
            hdr = table.rows[0].cells
            for cell, label in zip(hdr, ("No.", "Term / Condition")):
                cell.text = ""
                run = cell.paragraphs[0].add_run(label)
                run.bold = True
                shd = OxmlElement("w:shd")
                shd.set(qn("w:val"), "clear")
                shd.set(qn("w:color"), "auto")
                shd.set(qn("w:fill"), "D9E2F3")
                cell._tc.get_or_add_tcPr().append(shd)
            for i, item in enumerate(content, 1):  # type: ignore[arg-type]
                row = table.add_row().cells
                row[0].text = str(i)
                row[1].text = item
            table.autofit = False
            table.columns[0].width = Inches(0.7)
            table.columns[1].width = Inches(5.8)
            for row in table.rows:
                row.cells[0].width = Inches(0.7)
                row.cells[1].width = Inches(5.8)
            doc.add_paragraph()
        else:
            p = doc.add_paragraph(str(content))
            p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
            p.paragraph_format.space_after = Pt(6)

    footer = doc.sections[0].footer
    fp = footer.paragraphs[0]
    fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    fr = fp.add_run(config.FOOTER_TEXT + "  |  Page ")
    fr.italic = True
    fr.font.size = Pt(9)
    fr.font.color.rgb = RGBColor(0x55, 0x55, 0x55)
    _add_page_number(fp)

    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


# --------------------------------------------------------------------------- PDF
def _pdf_safe(s: str) -> str:
    """Core PDF fonts are latin-1 only."""
    s = str(s).replace("\u20b9", "INR ").replace("\u20ac", "EUR ")
    return s.encode("latin-1", "replace").decode("latin-1")


def format_pdf(text: str, doc_type: str, terms: str = "") -> bytes:
    """Branded PDF: logo header + footer with page numbers on every page."""
    from fpdf import FPDF

    title_text = _pdf_safe(doc_type or "Legal Document")

    class LegalPDF(FPDF):
        def header(self):
            if os.path.exists(config.LOGO_PATH):
                self.image(config.LOGO_PATH, x=(self.w - 40) / 2, y=8, w=40)
            self.set_y(22)
            self.set_font("Helvetica", "B", 10)
            self.cell(0, 6, title_text, align="C", new_x="LMARGIN", new_y="NEXT")
            self.set_draw_color(180, 180, 180)
            self.line(self.l_margin, 29, self.w - self.r_margin, 29)
            self.set_y(34)

        def footer(self):
            self.set_y(-15)
            self.set_font("Helvetica", "I", 8)
            self.set_text_color(90, 90, 90)
            self.cell(0, 10, _pdf_safe(f"{config.FOOTER_TEXT}  |  Page {self.page_no()}/{{nb}}"), align="C")
            self.set_text_color(0, 0, 0)

    pdf = LegalPDF(format="A4")
    pdf.alias_nb_pages()
    pdf.set_margins(22, 20, 22)
    pdf.set_auto_page_break(True, margin=22)
    pdf.add_page()

    def para(txt, indent=0.0, style="", size=11.5, align="J", gap=1.5):
        pdf.set_font("Times", style, size)
        pdf.set_x(pdf.l_margin + indent)
        pdf.multi_cell(0, 5.8, _pdf_safe(txt), align=align, new_x="LMARGIN", new_y="NEXT")
        pdf.ln(gap)

    for kind, content in build_blocks(text, doc_type, terms):
        if kind == "title":
            para(str(content), style="B", size=15, align="C", gap=4)
        elif kind == "heading":
            pdf.ln(2)
            para(str(content), style="B", size=12, align="L", gap=1)
        elif kind == "sub":
            para(str(content), indent=8, gap=0.5)
        elif kind == "bullet":
            para("-  " + str(content), indent=6, gap=0.5)
        elif kind == "terms":
            for item in content:  # type: ignore[union-attr]
                para("-  " + item, indent=6, gap=0.5)
            pdf.ln(2)
        else:
            para(str(content))

    return bytes(pdf.output())
