"""LegalEase - Streamlit frontend.  Run:  streamlit run frontend/app.py"""
import os
import sys

# Make project root importable (streamlit puts only /frontend on sys.path)
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import requests
import streamlit as st

import config
from ai_core.generator import (
    format_docx,
    format_html_preview,
    format_pdf,
    safe_filename,
    sanitize_text,
)

st.set_page_config(page_title="LegalEase", page_icon="⚖️", layout="centered")

# ---------------------------------------------------------------- session state
for key, default in {
    "doc_text": "",
    "doc_type": "",
    "doc_terms": "",
    "editing": False,
}.items():
    st.session_state.setdefault(key, default)


def _start_edit():
    st.session_state.editor_text = st.session_state.doc_text
    st.session_state.editing = True


def _stop_edit():
    st.session_state.editing = False


def _sync_edit():
    st.session_state.doc_text = st.session_state.editor_text


# ---------------------------------------------------------------- header
col1, col2, col3 = st.columns([1, 2, 1])
with col2:
    if os.path.exists(config.WEB_LOGO_PATH):
        st.image(config.WEB_LOGO_PATH, use_container_width=True)
    else:
        st.markdown("<h1 style='text-align:center;'>⚖️ LegalEase</h1>", unsafe_allow_html=True)

st.markdown("<h2 style='text-align: center;'>AI Legal Document Generator</h2>", unsafe_allow_html=True)

# ---------------------------------------------------------------- inputs
document_type = st.text_input("Document Type (Ex: Agreement, Contract, NDA)", placeholder="Freelance Work Contract")
parties = st.text_area(
    "Parties Involved",
    placeholder="Jane Doe (Service Provider), TechNova Inc. (Client)",
)
terms = st.text_area(
    "Terms & Conditions (Use semicolons for bullet points)",
    placeholder="Work must be delivered by May 15, 2025; Payment within 7 days of invoice; "
    "Confidentiality must be maintained at all times",
)
dates = st.text_input("Effective Date", placeholder="April 15, 2025")

# ---------------------------------------------------------------- generate
if st.button("Generate Document", type="primary"):
    if not document_type.strip() or not parties.strip():
        st.warning("Please fill in at least the Document Type and Parties Involved.")
    else:
        with st.spinner("Drafting your document with Gemini..."):
            try:
                resp = requests.post(
                    f"{config.BACKEND_URL}/generate",
                    json={
                        "document_type": document_type.strip(),
                        "parties": parties.strip(),
                        "terms": terms.strip(),
                        "dates": dates.strip(),
                    },
                    timeout=180,
                )
                if resp.status_code == 200:
                    st.session_state.doc_text = sanitize_text(resp.json()["document"])
                    st.session_state.doc_type = document_type.strip()
                    st.session_state.doc_terms = terms.strip()
                    st.session_state.editing = False
                    st.success("✅ Document Generated Successfully!")
                else:
                    try:
                        detail = resp.json().get("detail", resp.text)
                    except ValueError:
                        detail = resp.text
                    st.error(f"Backend error ({resp.status_code}): {detail}")
            except requests.exceptions.ConnectionError:
                st.error(
                    f"Cannot reach the backend at {config.BACKEND_URL}. "
                    "Start it with: uvicorn legalEaseAPI.main:app --reload"
                )
            except requests.exceptions.Timeout:
                st.error("The request timed out. Please try again.")
            except Exception as exc:
                st.error(f"Unexpected error: {exc}")

# ---------------------------------------------------------------- preview / edit / download
if st.session_state.doc_text:
    text = st.session_state.doc_text
    dtype = st.session_state.doc_type
    dterms = st.session_state.doc_terms

    styled_html = format_html_preview(text)
    st.markdown(
        "<div style='background:#0f172a;border:1px solid #1e293b;border-radius:10px;padding:20px;"
        f"max-height:420px;overflow-y:auto;color:#e2e8f0;'>{styled_html}</div>",
        unsafe_allow_html=True,
    )
    st.caption("AI-generated draft. Review with a qualified legal professional before signing.")

    if not st.session_state.editing:
        st.button("✏️ Click to Edit Document", on_click=_start_edit)
    else:
        st.text_area("Edit Document Below:", key="editor_text", height=350, on_change=_sync_edit)
        st.button("✔️ Done Editing", on_click=_stop_edit)

    st.download_button(
        "📄 Download as .TXT",
        data=text,
        file_name=safe_filename(dtype, "txt"),
        mime="text/plain",
    )
    try:
        st.download_button(
            "📝 Download as .DOCX",
            data=format_docx(text, dtype, dterms),
            file_name=safe_filename(dtype, "docx"),
            mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        )
    except Exception as exc:
        st.error(f"Could not build DOCX: {exc}")
    try:
        st.download_button(
            "📕 Download as .PDF",
            data=format_pdf(text, dtype, dterms),
            file_name=safe_filename(dtype, "pdf"),
            mime="application/pdf",
        )
    except Exception as exc:
        st.error(f"Could not build PDF: {exc}")
else:
    st.info("Click 'Generate Document' to start")
