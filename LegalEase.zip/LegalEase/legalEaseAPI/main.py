"""FastAPI entry point.  Run:  uvicorn legalEaseAPI.main:app --reload"""
import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

import config
from legalEaseAPI.routes import router

logging.basicConfig(level=logging.INFO)

app = FastAPI(title="LegalEase - AI Legal Document Generator", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8501", "http://127.0.0.1:8501"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router)


@app.get("/")
def home():
    return {"message": "Welcome to LegalEase AI Legal Document Generator API"}


@app.get("/health")
def health():
    return {
        "status": "ok",
        "model": config.GEMINI_MODEL,
        "api_key_configured": bool(config.GEMINI_API_KEY),
        "mock_mode": config.MOCK_MODE,
    }


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
