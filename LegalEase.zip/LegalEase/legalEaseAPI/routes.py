"""API routes for LegalEase."""
import logging

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from ai_core.gemini_generator import GeminiDocumentGenerator, GeminiError

log = logging.getLogger("legalease.api")

router = APIRouter()
gemini_generator = GeminiDocumentGenerator()


class DocumentRequest(BaseModel):
    document_type: str = Field(..., min_length=2, max_length=150)
    parties: str = Field(..., min_length=2, max_length=3000)
    terms: str = Field("", max_length=8000)
    dates: str = Field("", max_length=100)


@router.post("/generate")
def generate_legal_document(request: DocumentRequest):
    try:
        response = gemini_generator.generate_document(
            request.document_type,
            request.parties,
            request.terms,
            request.dates,
        )
    except GeminiError as exc:
        log.error("Generation failed: %s", exc)
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    except Exception as exc:  # unexpected
        log.exception("Unexpected error")
        raise HTTPException(status_code=500, detail=f"Unexpected server error: {exc}") from exc
    return {"document": response}
