"""Offline tests (no API key needed). Run:  pytest -v"""
import os
import sys

os.environ["MOCK_MODE"] = "true"
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fastapi.testclient import TestClient

from ai_core.generator import (
    build_blocks, format_docx, format_html_preview, format_pdf, sanitize_text, split_terms,
)
from legalEaseAPI.main import app

client = TestClient(app)
PAYLOAD = {
    "document_type": "Freelance Work Contract",
    "parties": "Jane Doe (Service Provider), TechNova Inc. (Client)",
    "terms": "Deliver by May 15, 2025; Payment within 7 days; Either party may terminate with 15 days notice",
    "dates": "April 15, 2025",
}


def test_root_and_health():
    assert client.get("/").status_code == 200
    assert client.get("/health").json()["mock_mode"] is True


def test_generate_ok_and_validation():
    r = client.post("/generate", json=PAYLOAD)
    assert r.status_code == 200 and "Jane Doe" in r.json()["document"]
    assert client.post("/generate", json={"document_type": "NDA"}).status_code == 422


def test_sanitize_and_terms():
    assert sanitize_text("\u201cHi\u201d \u2014 **bold**\n## Head") == '"Hi" - bold\nHead'
    assert split_terms("a; b;\n c;") == ["a", "b", "c"]


def test_exports():
    text = sanitize_text(client.post("/generate", json=PAYLOAD).json()["document"])
    assert any(k == "terms" for k, _ in build_blocks(text, "X", PAYLOAD["terms"]))
    assert "<h2" in format_html_preview(text)
    assert format_docx(text, "Freelance Work Contract", PAYLOAD["terms"])[:2] == b"PK"
    assert format_pdf(text, "Freelance Work Contract", PAYLOAD["terms"])[:4] == b"%PDF"
